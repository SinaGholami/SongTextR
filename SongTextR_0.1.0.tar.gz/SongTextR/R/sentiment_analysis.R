#' Analyze Sentiment of Lyrics
#'
#' This function performs a simple sentiment analysis on the lyrics using the 'syuzhet' lexicon.
#'
#' @param text A character string of cleaned lyrics.
#'
#' @return A named vector of sentiment scores (e.g. joy, anger, trust, etc.)
#'
#' @examples
#' lyrics <- "I’m parked out by the lake and I’m feeling happy and calm."
#' cleaned <- clean_lyrics(lyrics)
#' sentiment_analysis(cleaned)
#'
#' @export
sentiment_analysis <- function(text) {
  sentiment_scores <- syuzhet::get_nrc_sentiment(text)
  barplot(colSums(sentiment_scores), las = 2, col = rainbow(10),
          ylab = "Count", main = "Sentiment Analysis")
}

