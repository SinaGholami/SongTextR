#' Clean Song Lyrics
#'
#' This function takes raw song lyrics and cleans them by removing punctuation, numbers, and extra whitespace.
#'
#' @param text A character string containing the lyrics.
#'
#' @return A cleaned character string with only lowercase words and no extra symbols.
#'
#' @examples
#' clean_lyrics("I'm parked out by the lake - eighty miles from Santa Fe!")
#'
#' @export
clean_lyrics <- function(text) {
  text <- tolower(text)
  text <- gsub("[[:punct:]]", "", text)
  text <- gsub("[[:digit:]]", "", text)
  text <- gsub("\\s+", " ", text)
  text <- trimws(text)
  return(text)
}