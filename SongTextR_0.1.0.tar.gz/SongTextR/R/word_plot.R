#' Plot Word Frequency
#'
#' This function takes a cleaned character string and plots a bar chart of the most frequent words.
#'
#' @param text A cleaned character string (e.g. from clean_lyrics()).
#' @param top_n An integer. Number of top frequent words to display. Default is 10.
#'
#' @return A ggplot2 bar plot showing the frequency of the top words.
#'
#' @examples
#' lyrics <- "I’m parked out by the lake – eighty miles from Santa Fe, and I'm parked..."
#' cleaned <- clean_lyrics(lyrics)
#' word_plot(cleaned)
#'
#' @export
word_plot <- function(text, top_n = 10) {
  words <- strsplit(text, "\\s+")[[1]]
  df <- data.frame(words = words)
  df |>
    dplyr::count(words, sort = TRUE) |>
    dplyr::top_n(top_n) |>
    ggplot2::ggplot(ggplot2::aes(x = reorder(words, n), y = n, fill = n)) +
    ggplot2::geom_bar(stat = "identity") +
    ggplot2::coord_flip() +
    ggplot2::theme_minimal() +
    ggplot2::labs(title = paste("Top", top_n, "Words"), x = "Words", y = "Count") +
    ggplot2::theme(legend.position = "none")
}
