library(testthat)
library(SongTextR)

test_that("sentiment_analysis runs without error", {
  lyrics <- "I’m parked out by the lake and I’m feeling happy and calm."
  cleaned <- clean_lyrics(lyrics)

  expect_error(sentiment_analysis(cleaned), NA)
})
