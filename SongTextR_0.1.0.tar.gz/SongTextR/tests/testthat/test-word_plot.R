library(SongTextR)
test_that("count_words returns a data frame with correct counts", {
  input <- "apple banana apple orange banana apple"
  result <- word_plot(input)

  expect_true("apple" %in% result$data$word)
  expect_equal(result$data$n[result$data$words == "apple"], 3)
  expect_equal(result$data$n[result$data$words == "banana"], 2)
  expect_equal(result$data$n[result$data$words == "orange"], 1)
})

test_that("count_words handles empty input", {
  input <- ""
  result <- word_plot(input)
  expect_true(nrow(result$data) == 0)
})
