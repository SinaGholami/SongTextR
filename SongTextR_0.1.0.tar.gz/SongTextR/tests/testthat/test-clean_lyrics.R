library(SongTextR)
test_that("clean_lyrics removes punctuation and converts to lowercase", {
  input <- "Hello, World! This is: a Test."
  expected <- "hello world this is a test"
  result <- clean_lyrics(input)
  expect_equal(result, expected)
})

test_that("clean_text handles empty input", {
  input <- ""
  expected <- ""
  result <- clean_lyrics(input)
  expect_equal(result, expected)
})
